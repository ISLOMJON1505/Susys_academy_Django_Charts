from django.shortcuts import render
from .models import *

def home(request):
    posts = Post.objects.all()
    context = {
        'posts': posts
    }
    return render(request, 'index.html', context)

def example(request):
    posts = Post.objects.all()
    context = {
        'posts': posts
    }
    return render(request, 'examp.html', context)

def piechart(request):
    posts = Post.objects.all()
    context = {
        'posts' : posts
    }
    return render(request, 'piechart.html', context)

def variable_radius(request):
    posts = Post.objects.all()
    context = {
        'posts' : posts
    }
    return render(request, 'variable_radius.html', context)

def scatter(request):
    posts = Post.objects.all()
    context = {
        'posts' : posts
    }
    return render(request, 'scatter.html', context)

def gauge(request):
    posts = Post.objects.all()
    context = {
        'posts' : posts
    }
    return render(request, 'gauge.html', context)

def piramida(request):
    posts = Post.objects.all()
    context = {
        'posts' : posts
    }
    return render(request, 'piramida.html', context)

def axes(request):
    posts = Post.objects.all()
    context = {
        'posts' : posts
    }
    return render(request, 'axes.html', context)
    