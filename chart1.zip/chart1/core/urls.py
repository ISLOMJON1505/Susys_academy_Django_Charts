from django.urls import path
from .views import *

urlpatterns = [
    path('', home),
    path('example/', example),
    path('piechart/', piechart),
    path('variable_radius/', variable_radius),
    path('scatter/', scatter),
    path('gauge/', gauge),
    path('piramida/', piramida),
    path('axes/', axes)
]
